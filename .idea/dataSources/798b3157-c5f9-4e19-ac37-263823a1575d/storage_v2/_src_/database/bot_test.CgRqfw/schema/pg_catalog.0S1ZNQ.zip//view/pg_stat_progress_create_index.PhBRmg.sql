create view pg_stat_progress_create_index
            (pid, datid, datname, relid, index_relid, command, phase, lockers_total, lockers_done, current_locker_pid,
             blocks_total, blocks_done, tuples_total, tuples_done, partitions_total, partitions_done)
as
SELECT s.pid,
       s.datid,
       d.datname,
       s.relid,
       s.param7::oid AS index_relid,
       CASE s.param1
           WHEN 1 THEN 'CREATE INDEX'::text
           WHEN 2 THEN 'CREATE INDEX CONCURRENTLY'::text
           WHEN 3 THEN 'REINDEX'::text
           WHEN 4 THEN 'REINDEX CONCURRENTLY'::text
           ELSE NULL::text
           END       AS command,
       CASE s.param10
           WHEN 0 THEN 'initializing'::text
           WHEN 1 THEN 'waiting for writers before build'::text
           WHEN 2 THEN 'building index'::text ||
                       COALESCE(': '::text || pg_indexam_progress_phasename(s.param9::oid, s.param11), ''::text)
           WHEN 3 THEN 'waiting for writers before validation'::text
           WHEN 4 THEN 'index validation: scanning index'::text
           WHEN 5 THEN 'index validation: sorting tuples'::text
           WHEN 6 THEN 'index validation: scanning table'::text
           WHEN 7 THEN 'waiting for old snapshots'::text
           WHEN 8 THEN 'waiting for readers before marking dead'::text
           WHEN 9 THEN 'waiting for readers before dropping'::text
           ELSE NULL::text
           END       AS phase,
       s.param4      AS lockers_total,
       s.param5      AS lockers_done,
       s.param6      AS current_locker_pid,
       s.param16     AS blocks_total,
       s.param17     AS blocks_done,
       s.param12     AS tuples_total,
       s.param13     AS tuples_done,
       s.param14     AS partitions_total,
       s.param15     AS partitions_done
FROM pg_stat_get_progress_info('CREATE INDEX'::text) s(pid, datid, relid, param1, param2, param3, param4, param5,
                                                       param6, param7, param8, param9, param10, param11, param12,
                                                       param13, param14, param15, param16, param17, param18, param19,
                                                       param20)
         LEFT JOIN pg_database d ON s.datid = d.oid;

alter table pg_stat_progress_create_index
    owner to postgres;

grant select on pg_stat_progress_create_index to public;

